import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

class MLP(nn.Module):
    def __init__(self, input_size=3, hidden_size=3, output_size=3):
        super(MLP, self).__init__()
        ### YOUR CODE HERE
        self.fc1 = nn.Linear(input_size, hidden_size) # first linear layer
        self.fc2 = nn.Linear(hidden_size, output_size) # output layer
        ### END YOUR CODE

    def forward(self, x):
        ### YOUR CODE HERE
        x = F.relu(self.fc1(x)) # apply ReLu function
        x = self.fc2(x) # output layer
        ### END YOUR CODE
        return x
